import React, { useState } from "react";
import './Navbar.css';


const Navbar = () => {

    return (
        <nav className="navbar">
            <div className="navbar-left">
                
                <h1 className="navbar-title"><span style={{color:'#0A2F61'}}>Care</span><span style={{color:'#00000'}}>4</span><span style={{color:'#07ACE6'}}>today</span></h1>
                <h1 className="navbar-title1">Patient</h1>
                <h1 className="navbar-title2">Admin</h1>
            </div>
            
        </nav>
    );
};

export default Navbar;
