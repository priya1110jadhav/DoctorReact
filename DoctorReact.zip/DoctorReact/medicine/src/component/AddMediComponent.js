import React, { useState } from 'react';
import Navbar from './Navbar';
import './MainComponent.css';
import Popup from './Popup';
import Alert from './Alert'; // Import Alert component

const AddMediComponent = () => {
    const [popupVisible, setPopupVisible] = useState(false);
    const [alertVisible, setAlertVisible] = useState(false);
    const [alertType, setAlertType] = useState(''); // Track alert type ('success' or 'warning')
    const [alertMessage, setAlertMessage] = useState(''); // Track alert message
    const [medicines, setMedicines] = useState([
        { name: '14-Day cleanse 2-Part Tablets', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Alevazol Topical Ointment', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'TYLENOL COLD + FLU', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Relax & Sleep Tablet', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Muscle Rub Ultra Strength C', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
    ]);
    const [appointment, setAppointment] = useState([
        { name: 'Appointment went', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Appointment missed', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Appointment next 30 days', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Existing appointment went', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
        { name: 'Existing patient', description: '0.0, 0.0, 230.0Mg, 0.0, 0.0, 0.0, 516.0Mg,157.0Mg' },
    ]);

    const handleAddMedicineClick = () => {
        setPopupVisible(true);
    };

    const handleClosePopup = () => {
        setPopupVisible(false);
    };

    const handleSaveMedicine = (newMedicine) => {
        const isDuplicate = medicines.some(medicine => medicine.name.toLowerCase() === newMedicine.name.toLowerCase());
        const isAzithromycin = newMedicine.name.toLowerCase() === 'azithromycin';
    
        if (isDuplicate) {
            setAlertType('warning');
            setAlertMessage('This medicine already exists.');
        } else if (isAzithromycin) {
            setAlertType('warning');
            setAlertMessage('Azithromycin cannot be administered to this patient due to a drug-drug interaction with their current Tylenol Tablet.');
        } else {
            setMedicines([...medicines, { ...newMedicine, isNew: true }]);
            setAlertType('success');
            setAlertMessage('Medicine added successfully!');
        }
    
        setAlertVisible(true);
        setTimeout(() => {
            setAlertVisible(false);
        }, 5000); // Hide alert after 5 seconds
    };

    return (
        <div>
            <Navbar />
            <div className="main-container">
                <div className="breadcrumb">
                    <h1 className='breadcrumb-title'>
                        <span style={{ color: "#0A2F61", letterSpacing: '0.1em' }}>ANKITA DEMO</span> &gt; <span style={{ color: "#0E149F", letterSpacing: '0.1em' }}>PULMONARY ARTERIAL HYPERTENSION CARE MODULE</span>
                    </h1>
                </div>
                <div className='lines'>
                    <p><span style={{ color: '#868C8C', fontSize: '10px' }}>ADD MEDICATIONS AND/OR APPOINTMENTS</span></p>
                    <p><span style={{ color: '#868C8C', fontSize: '10px' }}>IMPORTANT: as the healthcare professional connected to this patient via Card4Today@connect</span></p>
                </div>
                <div className="profile-section">
                    <div className="Addprofile">
                        <div className='AddMedicine'>
                            <h3 className='appo'>MEDICINE</h3>
                            <img src='/images/mediplus.png' className="plus" alt="Logo" onClick={handleAddMedicineClick} />
                        </div>
                        <div className="profile-info">
                            {medicines.map((medicine, index) => (
                                <div className='tablet' key={index} style={{ backgroundColor: medicine.isNew ? '#e0f7fa' : 'white' }}>
                                    <p>{medicine.name}</p>
                                    <p><span style={{ color: '#868C8C' }}>{medicine.description}</span></p>
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="Addprofile">
                        <div className='AddMedicine'>
                            <h3 className='appo'>APPOINTMENTS</h3>
                            <img src='/images/appointmentplus.png' className="plus" alt="Logo" />
                        </div>
                        <div className="profile-info">
                            {appointment.map((appointment, index) => (
                                <div className='tablet' key={index} style={{ backgroundColor: appointment.isNew ? '#e0f7fa' : 'white' }}>
                                    <p>{appointment.name}</p>
                                    <p><span style={{ color: '#868C8C' }}>{appointment.description}</span></p>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </div>
            {popupVisible && <Popup onClose={handleClosePopup} onSave={handleSaveMedicine} medicines={medicines} />}
            {alertVisible && <Alert message={alertMessage} type={alertType} />}
        </div>
    );
};

export default AddMediComponent;
