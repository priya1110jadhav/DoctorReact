import React, { useState } from 'react';
import './Popup.css';

const Popup = ({ onClose, onSave, medicines }) => {
    const [medicineName, setMedicineName] = useState('');
    const [quantity, setQuantity] = useState('');

    const handleSaveClick = () => {
        if (medicineName && quantity) {
            const newMedicine = { name: medicineName, description: `${quantity} Mg` };
            onSave(newMedicine);
            setMedicineName('');
            setQuantity('');
        }
    };

    return (
        <div className="popup-overlay">
            <div className="popup-content">
                {/* <button className="close-button" onClick={onClose}>X</button> */}
                <button className="close-button" onClick={onClose}>
                    <img src="/images/close.png" alt="Close" className="close-icon" />
                </button>
                <h3>ADD MEDICINES</h3>
                <div className='popupflex'>
                    <div className="input-group" style={{ width: '400px' }}>
                        <label>Enter a Medicine Name</label>
                        <input 
                            type="text" 
                            value={medicineName} 
                            onChange={(e) => setMedicineName(e.target.value)} 
                        />
                    </div>
                    <div className="input-group" style={{ width: '80px' }}>
                        <label>Quantity</label>
                        <input 
                            type="text" 
                            value={quantity} 
                            onChange={(e) => setQuantity(e.target.value)} 
                        />
                    </div>
                    <button className="save-button" onClick={handleSaveClick}>Save</button>
                </div>
                <div className="history">
                    <h4>History</h4>
                    <table className="medicine-table">
                        <thead>
                            <tr>
                                <th style={{backgroundColor:'#EFF1F3'}}>Medicine Name</th>
                                <th style={{backgroundColor:'#EFF1F3'}}>Description</th>
                            </tr>
                        </thead>
                        <tbody>
                            {medicines.map((medicine, index) => (
                                <tr key={index} className="history-item">
                                    <td>{medicine.name}</td>
                                    <td>{medicine.description}</td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Popup;
