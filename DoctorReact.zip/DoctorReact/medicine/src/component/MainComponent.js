import React from 'react';
import { useNavigate } from 'react-router-dom';
import Navbar from './Navbar';
import './MainComponent.css';


const MainComponent = () => {
    const navigate = useNavigate();
    const handleEditClick = () => {
        navigate('/add'); // Navigate to the /add route
      };
  return (
    <div>

    <Navbar />
    <div className="main-container">
      <div className="breadcrumb">
        <h1 className='breadcrumb-title'> <span style={{color:"#0A2F61"}}>PATIENTS</span> &gt; <span style={{color:"#0E149F", letterSpacing:'0.1em'}}>ANKITADEMO PROD CADPAD</span></h1>
        <h1 className="export">EXPORT PROFILES</h1>
      </div>
      
      <div className="profile-section">
        <div className="profile">
          <h3 className='mainTitle'>PROFILE</h3>
          <div className="profile-info">
            <p className='content'>ANKITADEMO</p>
            <p className='content'> PROD CADPAD</p>
            <p className='content'> MAR 2, 1989</p>
            <p className='content'>PATIENT ID/MRN:8886</p>
            <p className='content'>EMAIL:ankitademo@mail.test</p>
            <p className='content'>CARE MODULE: Coronary Peripheral Artery Disease Care Module <button className="edit-button" onClick={handleEditClick}>(EDIT)</button></p>
            <p className='content'>STATUS: <span className="status-connected">CONNECTED</span> <button className="disconnect-button">(DISCONNECT)</button></p>
          </div>
        </div>
        <div className="right-section">
          <div className="medications">
            <h3 className='mainTitle'>MEDICATIONS</h3>
           <div className='medi-div'>
           <img src='/images/medicine.png' className="mediDiv" alt="Logo" />
           <p><span style={{color:'#868C8C', fontSize:'10px', fontWeight:'bold', letterSpacing:'0.1em'}}>NO MEDICATIONS</span></p>
           <p><span style={{color:'#868C8C', fontSize:'10px'}}>MEDICATIONS CAN ONLY BE ADDED ASSIGNING A CARE MODULE FOR THE PATIENT</span></p>

           </div>
          </div>
          <div className="appointments">
            <h3 className='mainTitle'>APPOINTMENTS</h3>
            <div className='medi-div'>
            <img src='/images/appointment.png' className="mediDiv" alt="Logo" />
            <p><span style={{color:'#868C8C', fontSize:'10px', fontWeight:'bold', letterSpacing:'0.1em'}}>NO APPOINTMENTS</span></p>
            <p><span style={{color:'#868C8C', fontSize:'10px'}}>APPOINTMENT CAN ONLY BE ADDED ASSIGNING A CARE MODULE FOR THE PATIENT</span></p>
            </div>
          </div>
        </div>
        </div>
    </div>
    </div>
  );
};

export default MainComponent;
