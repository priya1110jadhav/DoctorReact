import React from 'react';
import './Popup.css';

const Alert = ({ message, type }) => {
    const icon = type === 'success' ? '/images/success.png' : '/images/warning.png';
    const backgroundColor = type === 'success' ? '#5ad35e' : '#f0ad4e';
    const borderColor = type === 'success' ? '#0f5b11' : '#eea236';

    return (
        <div className="alert" style={{ backgroundColor, borderColor }}>
            <img src={icon} alt={type} className="alert-icon" />
            {message}
        </div>
    );
};

export default Alert;
