import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Navbar from './component/Navbar';
import MainComponent from './component/MainComponent';
import AddMediComponent from './component/AddMediComponent';


const App = () => {
  return (
    <Router>
      <div className="App">
        <Routes>
          {/* <Route path="/" element={<Navbar/>}/> */}
          
          <Route path="/" element={<MainComponent/>}/>
          <Route path="/add" element={<AddMediComponent/>}/>

        </Routes>
      </div>
    </Router>
  );
};

export default App;